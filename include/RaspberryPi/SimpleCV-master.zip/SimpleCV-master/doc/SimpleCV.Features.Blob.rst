SimpleCV.Features.Blob module
=============================

.. automodule:: SimpleCV.Features.Blob
    :members:
    :show-inheritance:
