SimpleCV.MachineLearning.ShapeContextClassifier module
======================================================

.. automodule:: SimpleCV.MachineLearning.ShapeContextClassifier
    :members:
    :show-inheritance:
