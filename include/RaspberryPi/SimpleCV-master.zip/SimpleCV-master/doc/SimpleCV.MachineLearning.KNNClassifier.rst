SimpleCV.MachineLearning.KNNClassifier module
=============================================

.. automodule:: SimpleCV.MachineLearning.KNNClassifier
    :members:
    :show-inheritance:
