SimpleCV.Features package
=========================

Submodules
----------

.. toctree::

   SimpleCV.Features.BOFFeatureExtractor
   SimpleCV.Features.Blob
   SimpleCV.Features.BlobMaker
   SimpleCV.Features.Detection
   SimpleCV.Features.EdgeHistogramFeatureExtractor
   SimpleCV.Features.FaceRecognizer
   SimpleCV.Features.FeatureExtractorBase
   SimpleCV.Features.FeatureUtils
   SimpleCV.Features.Features
   SimpleCV.Features.HaarCascade
   SimpleCV.Features.HaarLikeFeature
   SimpleCV.Features.HaarLikeFeatureExtractor
   SimpleCV.Features.HueHistogramFeatureExtractor
   SimpleCV.Features.MorphologyFeatureExtractor

Module contents
---------------

.. automodule:: SimpleCV.Features
    :members:
    :show-inheritance:
