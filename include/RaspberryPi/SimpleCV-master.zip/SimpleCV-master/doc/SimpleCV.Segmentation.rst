SimpleCV.Segmentation package
=============================

Submodules
----------

.. toctree::

   SimpleCV.Segmentation.ColorSegmentation
   SimpleCV.Segmentation.DiffSegmentation
   SimpleCV.Segmentation.MOGSegmentation
   SimpleCV.Segmentation.RunningSegmentation
   SimpleCV.Segmentation.SegmentationBase

Module contents
---------------

.. automodule:: SimpleCV.Segmentation
    :members:
    :show-inheritance:
