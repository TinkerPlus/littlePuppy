SimpleCV.Features.HaarCascade module
====================================

.. automodule:: SimpleCV.Features.HaarCascade
    :members:
    :show-inheritance:
