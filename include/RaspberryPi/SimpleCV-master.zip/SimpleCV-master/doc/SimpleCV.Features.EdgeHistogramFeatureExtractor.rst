SimpleCV.Features.EdgeHistogramFeatureExtractor module
======================================================

.. automodule:: SimpleCV.Features.EdgeHistogramFeatureExtractor
    :members:
    :show-inheritance:
