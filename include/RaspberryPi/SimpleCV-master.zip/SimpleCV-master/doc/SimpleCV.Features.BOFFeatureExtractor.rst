SimpleCV.Features.BOFFeatureExtractor module
============================================

.. automodule:: SimpleCV.Features.BOFFeatureExtractor
    :members:
    :show-inheritance:
