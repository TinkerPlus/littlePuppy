SimpleCV.Color module
=====================

.. automodule:: SimpleCV.Color
    :members:
    :show-inheritance:
