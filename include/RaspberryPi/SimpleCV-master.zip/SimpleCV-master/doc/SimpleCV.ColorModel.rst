SimpleCV.ColorModel module
==========================

.. automodule:: SimpleCV.ColorModel
    :members:
    :show-inheritance:
