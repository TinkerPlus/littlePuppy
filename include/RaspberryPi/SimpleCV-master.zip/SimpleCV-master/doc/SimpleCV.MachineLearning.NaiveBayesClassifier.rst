SimpleCV.MachineLearning.NaiveBayesClassifier module
====================================================

.. automodule:: SimpleCV.MachineLearning.NaiveBayesClassifier
    :members:
    :show-inheritance:
