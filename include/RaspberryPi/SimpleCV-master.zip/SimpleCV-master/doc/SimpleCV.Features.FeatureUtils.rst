SimpleCV.Features.FeatureUtils module
=====================================

.. automodule:: SimpleCV.Features.FeatureUtils
    :members:
    :show-inheritance:
