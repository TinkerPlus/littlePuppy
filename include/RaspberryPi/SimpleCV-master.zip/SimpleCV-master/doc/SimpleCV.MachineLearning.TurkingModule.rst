SimpleCV.MachineLearning.TurkingModule module
=============================================

.. automodule:: SimpleCV.MachineLearning.TurkingModule
    :members:
    :show-inheritance:
