SimpleCV.Segmentation.SegmentationBase module
=============================================

.. automodule:: SimpleCV.Segmentation.SegmentationBase
    :members:
    :show-inheritance:
