SimpleCV.MachineLearning package
================================

Submodules
----------

.. toctree::

   SimpleCV.MachineLearning.ConfusionMatrix
   SimpleCV.MachineLearning.KNNClassifier
   SimpleCV.MachineLearning.NaiveBayesClassifier
   SimpleCV.MachineLearning.SVMClassifier
   SimpleCV.MachineLearning.ShapeContextClassifier
   SimpleCV.MachineLearning.TemporalColorTracker
   SimpleCV.MachineLearning.TreeClassifier
   SimpleCV.MachineLearning.TurkingModule

Module contents
---------------

.. automodule:: SimpleCV.MachineLearning
    :members:
    :show-inheritance:
