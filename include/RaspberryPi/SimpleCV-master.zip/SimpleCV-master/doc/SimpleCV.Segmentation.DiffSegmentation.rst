SimpleCV.Segmentation.DiffSegmentation module
=============================================

.. automodule:: SimpleCV.Segmentation.DiffSegmentation
    :members:
    :show-inheritance:
