SimpleCV.Font module
====================

.. automodule:: SimpleCV.Font
    :members:
    :show-inheritance:
