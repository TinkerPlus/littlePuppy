SimpleCV.Camera module
======================

.. automodule:: SimpleCV.Camera
    :members:
    :show-inheritance:
